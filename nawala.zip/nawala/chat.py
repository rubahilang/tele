from telegram import Bot
import asyncio

TOKEN = '7171832900:AAG_FYjtv48anBXx2S4QoMbx2VbUR_X6Wh8'

async def get_chat_id(token):
    bot = Bot(token=token)
    updates = await bot.get_updates()
    for update in updates:
        print(f"Update: {update}")
        if update.message and update.message.chat:
            print(f"Chat ID: {update.message.chat.id}")
            break

if __name__ == "__main__":
    asyncio.run(get_chat_id(TOKEN))
