from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackContext
import json
import requests
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Token bot Telegram Anda
TOKEN = '7171832900:AAG_FYjtv48anBXx2S4QoMbx2VbUR_X6Wh8'

# ID grup (ganti dengan ID grup Anda)
GROUP_CHAT_ID = '-1002208375932'  # Ganti dengan ID grup Anda

# Fungsi untuk memuat data dari db.json
def load_data():
    try:
        with open('db.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {"websites": []}  # Initialize with a dictionary if the file is not found

# Fungsi untuk menyimpan data ke db.json
def save_data(data):
    with open('db.json', 'w') as file:
        json.dump(data, file, indent=4)

# Fungsi untuk memeriksa pemblokiran situs
def is_blocked(website):
    try:
        response = requests.get(website, allow_redirects=True)
        if 'Blokir' in response.text:
            return True
        return False
    except requests.RequestException:
        return True

async def check_and_notify(context: CallbackContext) -> None:
    data = load_data()
    websites = data.get('websites', [])

    for website in websites:
        logger.info(f"Checking website: {website}")
        if is_blocked(website):
            message = f"{website} terkena nawala/blokir oleh kominfo"
            logger.info(f"Sending message to group: {message}")
            try:
                await context.bot.send_message(chat_id=GROUP_CHAT_ID, text=message)
            except Exception as e:
                logger.error(f"Failed to send message to group: {e}")
        else:
            logger.info(f"Website {website} is not blocked")

# Handler untuk perintah /add
async def add_website(update: Update, context: CallbackContext) -> None:
    if len(context.args) != 1:
        await update.message.reply_text("Gunakan format: /add {website}")
        return

    website = context.args[0]

    # Muat data dari db.json
    data = load_data()

    # Tambahkan website ke data
    websites = data.get('websites', [])
    if website not in websites:
        websites.append(website)
        data['websites'] = websites
        save_data(data)
        await update.message.reply_text(f"Website {website} telah ditambahkan.")
    else:
        await update.message.reply_text(f"Website {website} sudah ada dalam daftar.")

# Handler untuk perintah /delete
async def delete_website(update: Update, context: CallbackContext) -> None:
    if len(context.args) != 1:
        await update.message.reply_text("Gunakan format: /delete {website}")
        return

    website = context.args[0]

    # Muat data dari db.json
    data = load_data()

    # Hapus website dari data
    websites = data.get('websites', [])
    if website in websites:
        websites.remove(website)
        data['websites'] = websites
        save_data(data)
        await update.message.reply_text(f"Website {website} telah dihapus.")
    else:
        await update.message.reply_text(f"Website {website} tidak ditemukan dalam daftar.")

# Handler untuk perintah /check
async def check_website(update: Update, context: CallbackContext) -> None:
    if len(context.args) != 1:
        await update.message.reply_text("Gunakan format: /check {website}")
        return

    website = context.args[0]

    if is_blocked(website):
        await update.message.reply_text(f"{website} terkena nawala/blokir oleh kominfo")
    else:
        await update.message.reply_text(f"{website} tidak terkena blokir.")

# Fungsi utama untuk menjalankan bot
def main() -> None:
    # Inisialisasi application dan job queue
    application = Application.builder().token(TOKEN).build()
    job_queue = application.job_queue

    # Daftarkan handler perintah
    application.add_handler(CommandHandler('add', add_website))
    application.add_handler(CommandHandler('delete', delete_website))
    application.add_handler(CommandHandler('check', check_website))

    # Jadwalkan pemeriksaan berkala
    job_queue.run_repeating(check_and_notify, interval=3600, first=0)

    # Mulai bot
    application.run_polling()

if __name__ == '__main__':
    main()
