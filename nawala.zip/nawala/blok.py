import requests
from requests.exceptions import SSLError, RequestException

def check_redirect_or_block(url):
    try:
        # Mengirim permintaan GET dengan verifikasi SSL diaktifkan
        response = requests.get(url, allow_redirects=True)
        
        # Menampilkan status kode HTTP akhir setelah redirect
        final_url = response.url
        status_code = response.status_code
        
        print(f"URL akhir setelah redirect: {final_url}")
        print(f"Status kode: {status_code}")
        
        # Memeriksa apakah halaman mengandung kata "Blokir"
        if "Blokir" in response.text:
            print("Halaman mengandung pesan 'Blokir'.")
        else:
            print("Halaman tidak mengandung pesan 'Blokir'.")
    
    except SSLError as e:
        # Menangani kesalahan SSL dan menganggapnya sebagai indikasi blokir
        print(f"Terjadi kesalahan SSL saat mengakses URL: {e}")
        print("Situs web mungkin diblokir atau mengalami masalah sertifikat SSL.")
    
    except RequestException as e:
        # Menangani kesalahan lain dan menganggapnya sebagai indikasi blokir
        print(f"Terjadi kesalahan saat mengakses URL: {e}")
        print("Kemungkinan situs web diblokir atau masalah jaringan lainnya.")

# Contoh penggunaan
url_to_check = "http://wingaming77center.com/"
check_redirect_or_block(url_to_check)
